# Git Commands

git init - create a new git repo
git status - View the changes to your project code
git add - add files to staging area
git commit - Creates a new commit with files from staging area
get log - view recent commits